const html = async () => {

  return   /*html*/`
  <div id="home">
    <div class="container fill-height">
      <div class="row fill-height gap-30">
        <div class="col-6 flex items-center fill-height">
          <div class="text-white banner">
            <h2 class="title">Design e Tecnologia</h2>
            <span class="subtitle">para transformar o seu negocio.</span>
            <div class="mar-top-10 w-80">
              A DLW é especialista em Design e Tecnologia, oferecendo soluções
              que vão desde a criação da identidade visual até o
              desenvolvimento e otimização de sites. Nosso objetivo é
              criar soluções inteligentes que geram melhores resultados
              fortalecendo a identidade da sua marca e conquistando mais
              clientes online.
            </div>
          </div>
        </div>
        <div class="col-6 fill-height flex justify-center items-center desktop">
          <img
            height="400"
            src="/images/home-layout.png"
          />
        </div>
      </div>
    </div>
  </div>
`
}
module.exports = {
  html
}
